export class CreateVenuePhotoDto {
  venueId: number;
  url: string;
}
