import { Injectable } from '@nestjs/common';
import { CreateVenuePhotoDto } from './dto/create-venue_photo.dto';
import { UpdateVenuePhotoDto } from './dto/update-venue_photo.dto';
import { InjectModel } from '@nestjs/sequelize';
import { VenuePhoto } from './models/venue_photo.model';

@Injectable()
export class VenuePhotoService {
  constructor(@InjectModel(VenuePhoto) private venuePhotoModel: typeof VenuePhoto){
  }
  create(createVenuePhotoDto: CreateVenuePhotoDto) {
    return this.venuePhotoModel.create(createVenuePhotoDto);
  }

  findAll() {
    return  this.venuePhotoModel.findAll({include: {all: true}});
  }

  findOne(id: number) {
    return this.venuePhotoModel.findOne({
      where: {id},
      include: {all: true}
    });
  }

  update(id: number, updateVenuePhotoDto: UpdateVenuePhotoDto) {
    return `This action updates a #${id} venuePhoto`;
  }

  remove(id: number) {
    return `This action removes a #${id} venuePhoto`;
  }
}
