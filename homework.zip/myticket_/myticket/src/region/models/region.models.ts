import { BelongsTo, BelongsToMany, Column, DataType, HasMany, Model, Table } from 'sequelize-typescript';
import { Venue } from 'src/venue/models/venue.model';

interface RegionCreationArrt{
    name:string
}

@Table({tableName:"region", timestamps:false})
export class Region extends Model<Region , RegionCreationArrt>{
    @Column({
        type: DataType.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      })
      id: number;
      @Column({
        type: DataType.STRING,
      })
      name: string; 

      @HasMany(() => Venue)
      venues: Venue[];


}