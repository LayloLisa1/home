export class CreateRegionDto{
    name:string
}