import { Table, Column, Model, DataType, HasMany } from 'sequelize-typescript';
import { Venue } from 'src/venue/models/venue.model';
interface DistrictCreationAttr {
  name: string

}

@Table({ tableName: 'district' })
export class District extends Model<District, DistrictCreationAttr> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  name: string;

  @HasMany(() => Venue)
  venues: Venue[];
}
