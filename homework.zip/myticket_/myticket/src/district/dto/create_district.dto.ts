export class CreateDistrictDTO {
    name: string;
  }
  