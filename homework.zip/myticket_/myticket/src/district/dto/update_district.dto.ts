export class UpdateDistrictDTO {
    name?: string;
  }
  