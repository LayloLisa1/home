import { Module } from '@nestjs/common';
import { SequelizeModule } from '@nestjs/sequelize';
import { District } from './models/district_model';
import { DistrictService } from './district.service';
import { DistrictController } from './district.controller';
import { Venue } from '../venue/models/venue.model';
import { Seat } from '../seat/models/seat_model';

@Module({
  imports: [SequelizeModule.forFeature([District, Venue, Seat])],
  controllers: [DistrictController],
  providers: [DistrictService],
})
export class DistrictModule {}
