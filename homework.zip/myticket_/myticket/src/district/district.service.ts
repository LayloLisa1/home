import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { District } from './models/district_model';
import { CreateDistrictDTO } from './dto/create_district.dto';
import { UpdateDistrictDTO } from './dto/update_district.dto';

@Injectable()
export class DistrictService {
  constructor(
    @InjectModel(District)
    private districtModel: typeof District,
  ) {}

  async create(createDistrictDTO: CreateDistrictDTO): Promise<District> {
    return this.districtModel.create({ ...createDistrictDTO });
  }

  async findAll(): Promise<District[]> {
    return this.districtModel.findAll({ include: { all: true } });
  }

  async findOne(id: number): Promise<District> {
    const district = await this.districtModel.findByPk(id, { include: { all: true } });
    if (!district) {
      throw new NotFoundException('District not found');
    }
    return district;
  }

  async update(id: number, updateDistrictDTO: UpdateDistrictDTO): Promise<District> {
    const district = await this.findOne(id);
    return district.update({ ...updateDistrictDTO });
  }

  async remove(id: number): Promise<void> {
    const district = await this.findOne(id);
    await district.destroy();
  }
}
