import { Controller, Get, Post, Put, Delete, Param, Body } from '@nestjs/common';
import { DistrictService } from './district.service';
import { CreateDistrictDTO } from './dto/create_district.dto';
import { UpdateDistrictDTO } from './dto/update_district.dto';

@Controller('districts')
export class DistrictController {
  constructor(private readonly districtService: DistrictService) {}

  @Post()
  createDistrict(@Body() createDistrictDTO: CreateDistrictDTO) {
    return this.districtService.create(createDistrictDTO);
  }

  @Get()
  findAll() {
    return this.districtService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: number) {
    return this.districtService.findOne(id);
  }

  @Put(':id')
  updateDistrict(@Param('id') id: number, @Body() updateDistrictDTO: UpdateDistrictDTO) {
    return this.districtService.update(id, updateDistrictDTO);
  }

  @Delete(':id')
  deleteDistrict(@Param('id') id: number) {
    return this.districtService.remove(id);
  }
}
