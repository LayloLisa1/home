import exp from "constants";
import { Column, DataType, Model, Table } from "sequelize-typescript";

interface SeatTypeAttr {
    name: string
}

@Table({ tableName: "seat_type" })
export class SeatType extends Model<SeatType, SeatTypeAttr> {
  @Column({
    type: DataType.STRING(),
    allowNull: false,
    unique: true,
  })
  name: string;
}

//Table vazifasi nima va qanday malumotlar oladi