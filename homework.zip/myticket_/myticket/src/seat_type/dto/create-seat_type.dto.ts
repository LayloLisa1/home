export class CreateSeatTypeDto {
  name: string;
}
