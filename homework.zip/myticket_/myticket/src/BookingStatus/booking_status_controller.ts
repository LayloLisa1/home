import { Controller, Get, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { BookingStatusService } from './booking_status_service';
import { BookingStatus } from './models/booking_status_model';

@Controller('booking-status')
export class BookingStatusController {
  constructor(private readonly bookingStatusService: BookingStatusService) {}

  @Post()
  create(@Body() bookingStatus: BookingStatus) {
    return this.bookingStatusService.create(bookingStatus);
  }

  @Get()
  findAll() {
    return this.bookingStatusService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: number) {
    return this.bookingStatusService.findOne(id);
  }

  @Put(':id')
  update(@Param('id') id: number, @Body() bookingStatus: Partial<BookingStatus>) {
    return this.bookingStatusService.update(id, bookingStatus);
  }

  @Delete(':id')
  delete(@Param('id') id: number) {
    return this.bookingStatusService.delete(id);
  }
}
