import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { BookingStatus } from './models/booking_status_model';

@Injectable()
export class BookingStatusService {
  constructor(
    @InjectModel(BookingStatus)
    private bookingStatusModel: typeof BookingStatus,
  ) {}

  async create(bookingStatus: Partial<BookingStatus>): Promise<BookingStatus> {
    return this.bookingStatusModel.create(bookingStatus);
  }

  async findAll(): Promise<BookingStatus[]> {
    return this.bookingStatusModel.findAll();
  }

  async findOne(id: number): Promise<BookingStatus> {
    const bookingStatus = await this.bookingStatusModel.findByPk(id);
    if (!bookingStatus) {
      throw new NotFoundException(`BookingStatus with id ${id} not found`);
    }
    return bookingStatus;
  }

  async update(id: number, bookingStatus: Partial<BookingStatus>): Promise<BookingStatus> {
    const [updatedCount, [updatedBookingStatus]] = await this.bookingStatusModel.update(bookingStatus, {
      where: { id },
      returning: true,  
    });

    if (updatedCount === 0) {
      throw new NotFoundException(`BookingStatus with id ${id} not found`);
    }

    return updatedBookingStatus;
  }

  async delete(id: number): Promise<void> {
    const bookingStatus = await this.findOne(id);  // This will throw an error if not found
    await bookingStatus.destroy();
  }
}
