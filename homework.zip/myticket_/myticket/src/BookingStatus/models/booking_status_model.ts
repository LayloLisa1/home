import { Column, Model, Table, HasMany } from 'sequelize-typescript';
import { Seat } from 'src/seat/models/seat_model';
import { Venue } from 'src/venue/models/venue.model';

@Table
export class BookingStatus extends Model<BookingStatus> {
  @Column
  name: string;

  @HasMany(() => Seat)
  seats: Seat[];

  @HasMany(() => Venue)
  venues: Venue[];
}
