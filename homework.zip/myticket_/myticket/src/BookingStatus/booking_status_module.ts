import { Module } from '@nestjs/common';
import { SequelizeModule } from '@nestjs/sequelize';
import { BookingStatus } from './models/booking_status_model';
import { BookingStatusService } from './booking_status_service';
import { BookingStatusController } from './booking_status_controller';

@Module({
  imports: [SequelizeModule.forFeature([BookingStatus])],
  providers: [BookingStatusService],
  controllers: [BookingStatusController],
})
export class BookingStatusModule {}
