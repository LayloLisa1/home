import { Controller, Post, Get, Param, Patch, Delete, Body } from '@nestjs/common';
import { EventTypeService } from './event-type.service'; 
import { CreateEventTypeDto } from './dto/create-event_type';
import { UpdateEventTypeDto } from './dto/update-event_type';
import { EventType } from './models/event_type.model';

@Controller()
export class EventTypeController {
  constructor(private readonly eventTypeService: EventTypeService) {}

  @Post()
  create(@Body() createEventTypeDto: CreateEventTypeDto): Promise<EventType> {
    return this.eventTypeService.create(createEventTypeDto);
  }

  @Get()
  findAll(): Promise<EventType[]> { 
    return this.eventTypeService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string): Promise<EventType> { 
    return this.eventTypeService.findOne(+id); 
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateEventTypeDto: UpdateEventTypeDto): Promise<[number, EventType[]]> { // Adjust return type for update
    return this.eventTypeService.update(+id, updateEventTypeDto); 
  }

  @Delete(':id')
  remove(@Param('id') id: string): Promise<void> {
    return this.eventTypeService.remove(+id); 
  }
}
