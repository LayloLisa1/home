import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { EventType } from 'src/EventType/models/event_type.model'; 
import { CreateEventTypeDto } from 'src/EventType/dto/create-event_type'; 
import { UpdateEventTypeDto } from 'src/EventType/dto/update-event_type'; 
import { NotFoundException } from '@nestjs/common';

@Injectable()
export class EventTypeService {
  constructor(@InjectModel(EventType) private eventTypeModel: typeof EventType) {}

  async create(createEventTypeDto: CreateEventTypeDto): Promise<EventType> {
    return this.eventTypeModel.create(createEventTypeDto);
  }

  async findAll(): Promise<EventType[]> {
    return this.eventTypeModel.findAll();
  }

  async findOne(id: number): Promise<EventType> {
    const eventType = await this.eventTypeModel.findByPk(id);
    if (!eventType) {
      throw new NotFoundException(`EventType with ID ${id} not found`);
    }
    return eventType;
  }

  async update(id: number, updateEventTypeDto: UpdateEventTypeDto): Promise<[number, EventType[]]> {
    const [affectedCount, affectedRows] = await this.eventTypeModel.update(updateEventTypeDto, {
      where: { id },
      returning: true, 
    });
    if (affectedCount === 0) {
      throw new NotFoundException(`EventType with ID ${id} not found`);
    }
    return [affectedCount, affectedRows];
  }

  async remove(id: number): Promise<void> {
    const deletedCount = await this.eventTypeModel.destroy({ where: { id } });
    if (deletedCount === 0) {
      throw new NotFoundException(`EventType with ID ${id} not found`);
    }
  }
}
