export class CreateEventTypeDto {
    readonly name: string;
    readonly parent_event_type_id?: number;
  }