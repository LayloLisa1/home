export class CreateVenueDto {
  name: string;
  address: string;
  location: string;
  site: string;
  phone: string;
  regionId: number;
  districtId:number
}
