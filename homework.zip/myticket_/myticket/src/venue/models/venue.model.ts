import {
  BelongsTo,
  Column,
  DataType,
  ForeignKey,
  HasMany,
  Model,
  Table,
} from "sequelize-typescript";
import { Region } from "src/region/models/region.models";
import { VenuePhoto } from "src/venue_photo/models/venue_photo.model";
import { District } from "src/district/models/district_model";
// import {Seat} from 'src/seat/models/seat_model';
import { TicketStatus } from "src/TicketStatus/models/ticket_status_model";
import { CartStatus } from 'src/cartStatus/models/cart_status.model';

interface VenueCreationAttr {
  name: string;
  address: string;
  location: string;
  site: string;
  phone: string;
  districtId:number;
  regionId:number
}
@Table({ tableName: "venue", timestamps: false })
export class Venue extends Model<Venue, VenueCreationAttr> {
  @Column({
    type: DataType.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  })
  id: number;
  @Column({
    type: DataType.STRING,
  })
  name: string;
  @Column({
    type: DataType.STRING,
  })
  address: string;
  @Column({
    type: DataType.STRING,
  })
  location: string;
  @Column({
    type: DataType.STRING,
  })
  site: string;
  @Column({
    type: DataType.STRING(15),
    unique: true,
  })
  phone: string;
  @HasMany(()=> VenuePhoto)
  venue_photos: VenuePhoto[];
  
  @ForeignKey(()=>Region)
  @Column({
    type:DataType.INTEGER,
  })
  regionId:number;
  @BelongsTo(() => Region)
  region:Region;


  @ForeignKey(() => District)
  @Column({
    type: DataType.INTEGER,
  })
  districtId: number;

  @BelongsTo(() => District)
  district: District;

  // @HasMany(() => Seat)
  // seats: Seat[];

  @ForeignKey(() => TicketStatus)
  @Column(DataType.INTEGER)
  ticketStatusId: number;


  @ForeignKey(() => CartStatus)
  @Column
  cartStatusId: number;

  // @BelongsTo(() => CartStatus)
  // cartStatus: CartStatus;


}
