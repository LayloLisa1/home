import { Column, DataType, ForeignKey, Table, Model, BelongsTo } from "sequelize-typescript";
import { VenueType } from "src/venue type/models/venue_type.model";
import { Venue } from "src/venue/models/venue.model";

interface IVenueVenueTypeCreationArrt{
    venueId: number;
    venueTypeId: number;
}
@Table({tableName: " venue_venue_type", timestamps: false})
export class IVenueVenueType extends Model<IVenueVenueType, IVenueVenueTypeCreationArrt>{
    @ForeignKey(() => Venue)
    @Column({type:DataType.INTEGER})
    venueId:number;
    @ForeignKey(() => VenueType)
    @Column({type:DataType.INTEGER})
    venueTypeId:number;

    @BelongsTo(() => Venue)
    venue: Venue;

    @BelongsTo(()=>VenueType)
    venue_type: VenueType;
}