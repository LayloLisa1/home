import { Injectable } from '@nestjs/common';
import { TicketStatus } from './models/ticket_status_model';

@Injectable()
export class TicketStatusService {
  async create(name: string): Promise<TicketStatus> {
    return await TicketStatus.create({ name });
  }

  async findAll(): Promise<TicketStatus[]> {
    return await TicketStatus.findAll();
  }

  async findOne(id: number): Promise<TicketStatus> {
    return await TicketStatus.findByPk(id);
  }

  async update(id: number, name: string): Promise<TicketStatus> {
    const ticketStatus = await this.findOne(id);
    if (ticketStatus) {
      ticketStatus.name = name;
      await ticketStatus.save();
    }
    return ticketStatus;
  }

  async remove(id: number): Promise<void> {
    const ticketStatus = await this.findOne(id);
    if (ticketStatus) {
      await ticketStatus.destroy();
    }
  }
}
