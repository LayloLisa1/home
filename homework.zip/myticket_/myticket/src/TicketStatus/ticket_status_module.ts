import { Module } from '@nestjs/common';
import { TicketStatusController } from './ticket_status_controller';
import { TicketStatusService } from './ticket_status_service';
import { SequelizeModule } from '@nestjs/sequelize';
import { TicketStatus } from './models/ticket_status_model';

@Module({
  imports: [SequelizeModule.forFeature([TicketStatus])],
  controllers: [TicketStatusController],
  providers: [TicketStatusService],
})
export class TicketStatusModule {}
