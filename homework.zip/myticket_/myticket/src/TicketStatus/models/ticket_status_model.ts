import { Column, DataType, Model, Table } from 'sequelize-typescript';
import { Venue } from 'src/venue/models/venue.model';
import { Seat } from 'src/seat/models/seat_model';
@Table
export class TicketStatus extends Model<TicketStatus> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  name: string;
}
