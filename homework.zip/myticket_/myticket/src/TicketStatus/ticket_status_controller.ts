import { Body, Controller, Delete, Get, Param, Post, Put } from '@nestjs/common';
import { TicketStatusService } from './ticket_status_service';
import { TicketStatus } from './models/ticket_status_model';
import { CreateTicketStatusDto } from './dto/create_ticket_status.dto';
import { UpdateTicketStatusDto } from './dto/update_ticket_status.dto';

@Controller('ticket-status')
export class TicketStatusController {
  constructor(private readonly ticketStatusService: TicketStatusService) {}

  @Post()
  create(@Body() createTicketStatusDto: CreateTicketStatusDto): Promise<TicketStatus> {
    return this.ticketStatusService.create(createTicketStatusDto.name);
  }

  @Get()
  findAll(): Promise<TicketStatus[]> {
    return this.ticketStatusService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: number): Promise<TicketStatus> {
    return this.ticketStatusService.findOne(id);
  }

  @Put(':id')
  update(@Param('id') id: number, @Body() updateTicketStatusDto: UpdateTicketStatusDto): Promise<TicketStatus> {
    return this.ticketStatusService.update(id, updateTicketStatusDto.name);
  }

  @Delete(':id')
  remove(@Param('id') id: number): Promise<void> {
    return this.ticketStatusService.remove(id);
  }
}