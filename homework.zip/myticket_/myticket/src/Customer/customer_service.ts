import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Customer } from 'src/Customer/models/customer_model';
import { CreateCustomerDto  } from './dto/create_customer';
import { UpdateCustomerDto } from './dto/update_customer';

@Injectable()
export class CustomerService {
  constructor(@InjectModel(Customer) private customerModel: typeof Customer) {}

  create(createCustomerDto: CreateCustomerDto) {
    return this.customerModel.create(createCustomerDto);
  }

  findAll() {
    return this.customerModel.findAll();
  }

  findOne(id: string) {
    return this.customerModel.findByPk(id);
  }

  update(id: string, updateCustomerDto: UpdateCustomerDto) {
    return this.customerModel.update(updateCustomerDto, { where: { id } });
  }

  remove(id: string) {
    return this.customerModel.destroy({ where: { id } });
  }
}
