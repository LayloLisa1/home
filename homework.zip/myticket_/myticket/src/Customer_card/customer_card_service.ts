import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { CustomerCard } from 'src/Customer_card/models/customer_card_model';
import { CreateCustomerCardDto,  } from './dto/create_customer_card';
import { UpdateCustomerCardDto} from './dto/update_customer_card';

@Injectable()
export class CustomerCardService {
  constructor(@InjectModel(CustomerCard) private customerCardModel: typeof CustomerCard) {}

  create(createCustomerCardDto: CreateCustomerCardDto) {
    return this.customerCardModel.create(createCustomerCardDto);
  }

  findAll() {
    return this.customerCardModel.findAll();
  }

  findOne(id: string) {
    return this.customerCardModel.findByPk(id);
  }

  update(id: string, updateCustomerCardDto: UpdateCustomerCardDto) {
    return this.customerCardModel.update(updateCustomerCardDto, { where: { id } });
  }

  remove(id: string) {
    return this.customerCardModel.destroy({ where: { id } });
  }
}
