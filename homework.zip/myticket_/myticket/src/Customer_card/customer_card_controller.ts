import { Controller, Post, Get, Param, Patch, Delete, Body } from '@nestjs/common';
import { CustomerCardService } from 'src/Customer_card/customer_card_service';
import { CreateCustomerCardDto } from './dto/create_customer_card';
import {UpdateCustomerCardDto} from './dto/update_customer_card'

@Controller('customer-cards')
export class CustomerCardController {
  constructor(private readonly customerCardService: CustomerCardService) {}

  @Post()
  create(@Body() createCustomerCardDto: CreateCustomerCardDto) {
    return this.customerCardService.create(createCustomerCardDto);
  }

  @Get()
  findAll() {
    return this.customerCardService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.customerCardService.findOne(id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateCustomerCardDto: UpdateCustomerCardDto) {
    return this.customerCardService.update(id, updateCustomerCardDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.customerCardService.remove(id);
  }
}
