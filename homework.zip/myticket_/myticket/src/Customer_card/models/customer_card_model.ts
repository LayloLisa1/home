// customer_card.model.ts
import { Column, Model, Table, DataType, ForeignKey } from 'sequelize-typescript';
import { Customer } from 'src/Customer/models/customer_model';

@Table
export class CustomerCard extends Model<CustomerCard> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  cardNumber: string;

  @Column({
    type: DataType.DATE,
    allowNull: false,
  })
  expirationDate: Date;

  @ForeignKey(() => Customer)
  @Column({
    type: DataType.UUID,
    allowNull: false,
  })
  customerId: string; 
}
