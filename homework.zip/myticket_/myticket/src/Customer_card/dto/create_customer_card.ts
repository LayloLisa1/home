import { IsNotEmpty, IsString, IsDate } from 'class-validator';

export class CreateCustomerCardDto {
  @IsNotEmpty()
  @IsString()
  cardNumber: string;

  @IsNotEmpty()
  @IsDate()
  expirationDate: Date;

  @IsNotEmpty()
  @IsString()
  customerId: string; 
}