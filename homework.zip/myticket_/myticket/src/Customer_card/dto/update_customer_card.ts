import { IsOptional, IsString, IsDate } from 'class-validator';

export class UpdateCustomerCardDto {
  @IsOptional()
  @IsString()
  cardNumber?: string;

  @IsOptional()
  @IsDate()
  expirationDate?: Date;

  @IsOptional()
  @IsString()
  customerId?: string; 
}
