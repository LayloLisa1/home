import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Language } from './models/language_model';
import { CreateLanguageDto } from './dto/create_language.dto';
import { UpdateLanguageDto } from './dto/update_language.dto';

@Injectable()
export class LanguageService {
  constructor(
    @InjectModel(Language)
    private readonly languageModel: typeof Language,
  ) {}

  create(createLanguageDto: CreateLanguageDto) {
    return this.languageModel.create(createLanguageDto);
  }

  findAll() {
    return this.languageModel.findAll();
  }

  findOne(id: string) {
    return this.languageModel.findByPk(id);
  }

  update(id: string, updateLanguageDto: UpdateLanguageDto) {
    return this.languageModel.update(updateLanguageDto, { where: { id } });
  }

  remove(id: string) {
    return this.languageModel.destroy({ where: { id } });
  }
}
