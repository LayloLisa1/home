import { Module } from '@nestjs/common';
import { LanguageService } from './language_service';
import { LanguageController } from './language_controller';
import { SequelizeModule } from '@nestjs/sequelize';
import { Language } from './models/language_model';

@Module({
  imports: [SequelizeModule.forFeature([Language])],
  controllers: [LanguageController],
  providers: [LanguageService],
})
export class LanguageModule {}
