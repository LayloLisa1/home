export class UpdateHumanCategoryDto {
  name?: string;
  start_age?: number;
  finish_age?: number;
  gender?: number;
}
