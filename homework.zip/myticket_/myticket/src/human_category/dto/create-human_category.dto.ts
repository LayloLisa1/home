export class CreateHumanCategoryDto {
  name: string;
  start_age: number;
  finish_age: number;
  gender: number;
}
