import { Controller, Post, Get, Param, Patch, Delete, Body } from '@nestjs/common';
import { TicketService } from './ticket.service';
import { CreateTicketDto } from './dto/create-ticket';
import { UpdateTicketDto } from './dto/update-ticket';
import { Ticket } from './models/ticket.model'; 

@Controller('tickets')
export class TicketController {
  constructor(private readonly ticketService: TicketService) {}

  @Post()
  async create(@Body() createTicketDto: CreateTicketDto): Promise<Ticket> {
    return this.ticketService.create(createTicketDto);
  }

  @Get()
  async findAll(): Promise<Ticket[]> {
    return this.ticketService.findAll();
  }

  @Get(':id')
  async findOne(@Param('id') id: string): Promise<Ticket> {
    const ticketId = parseInt(id, 10); 
    return this.ticketService.findOne(ticketId);
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() updateTicketDto: UpdateTicketDto): Promise<[number, Ticket[]]> {
    const ticketId = parseInt(id, 10); 
    return this.ticketService.update(ticketId, updateTicketDto);
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<void> {
    const ticketId = parseInt(id, 10);
    return this.ticketService.remove(ticketId);
  }
}
