import { Column, DataType, ForeignKey, Model, Table } from 'sequelize-typescript';
import { Event } from 'src/Event/models/event_model';

@Table({ tableName: 'ticket' })
export class Ticket extends Model<Ticket> {
  @Column({
    type: DataType.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  })
  id: number;

  @ForeignKey(() => Event)
  @Column({ type: DataType.BIGINT })
  event_id: number;

  @Column({ type: DataType.BIGINT })
  seat_id: number;

  @Column({ type: DataType.DECIMAL })
  price: number;

  @Column({ type: DataType.DECIMAL })
  service_fee: number;

  @Column({ type: DataType.SMALLINT })
  status_id: number; 

  @Column({ type: DataType.SMALLINT })
  ticket_type: number;
}