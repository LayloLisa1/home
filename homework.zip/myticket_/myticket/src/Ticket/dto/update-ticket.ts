export class UpdateTicketDto {
    readonly event_id?: number;
    readonly seat_id?: number;
    readonly price?: number;
    readonly service_fee?: number;
    readonly status_id?: number;
    readonly ticket_type?: number;
  }