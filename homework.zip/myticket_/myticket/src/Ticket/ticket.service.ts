import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Ticket } from './models/ticket.model';
import { CreateTicketDto } from './dto/create-ticket';
import { UpdateTicketDto } from './dto/update-ticket'; 

@Injectable()
export class TicketService {
  constructor(@InjectModel(Ticket) private ticketModel: typeof Ticket) {}

  async create(createTicketDto: CreateTicketDto): Promise<Ticket> {
    return this.ticketModel.create(createTicketDto);
  }

  async findAll(): Promise<Ticket[]> {
    return this.ticketModel.findAll();
  }

  async findOne(id: number): Promise<Ticket> {
    const ticket = await this.ticketModel.findByPk(id);
    if (!ticket) {
      throw new NotFoundException(`Ticket with ID ${id} not found`);
    }
    return ticket;
  }

  async update(id: number, updateTicketDto: UpdateTicketDto): Promise<[number, Ticket[]]> {
    const [affectedCount, affectedRows] = await this.ticketModel.update(updateTicketDto, {
      where: { id },
      returning: true, // This will return the updated instances
    });
    if (affectedCount === 0) {
      throw new NotFoundException(`Ticket with ID ${id} not found`);
    }
    return [affectedCount, affectedRows];
  }

  async remove(id: number): Promise<void> {
    const affectedCount = await this.ticketModel.destroy({ where: { id } });
    if (affectedCount === 0) {
      throw new NotFoundException(`Ticket with ID ${id} not found`);
    }
  }
}
