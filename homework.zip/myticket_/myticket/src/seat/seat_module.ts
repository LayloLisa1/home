import { Module } from '@nestjs/common';
import { SequelizeModule } from '@nestjs/sequelize';
import { Seat } from './models/seat_model';
import { SeatService } from './seat_service';
import { SeatController } from './seat_controller';

@Module({
  imports: [SequelizeModule.forFeature([Seat])],
  providers: [SeatService],
  controllers: [SeatController],
})
export class SeatModule {}
