import { IsOptional, IsString, IsNumber } from 'class-validator';

export class UpdateSeatDto {
  @IsOptional()
  @IsString()
  number?: string;

  @IsOptional()
  @IsString()
  type?: string;

  @IsOptional()
  @IsNumber()
  venueId?: number;
}
