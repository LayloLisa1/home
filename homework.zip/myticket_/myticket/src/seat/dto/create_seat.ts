import { IsNotEmpty, IsString, IsNumber } from 'class-validator';

export class CreateSeatDto {
  @IsNotEmpty()
  @IsString()
  number: string;

  @IsNotEmpty()
  @IsString()
  type: string;

  @IsNotEmpty()
  @IsNumber()
  venueId: number; 
}
