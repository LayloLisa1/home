import { Table, Column, Model, DataType, ForeignKey, BelongsTo } from 'sequelize-typescript';
import { Venue } from 'src/venue/models/venue.model';
import { TicketStatus } from 'src/TicketStatus/models/ticket_status_model';
import { CartStatus } from 'src/cartStatus/models/cart_status.model';
@Table({ tableName: 'seats' })
export class Seat extends Model<Seat> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  type: string;

  @ForeignKey(() => Venue)
  @Column({
    type: DataType.INTEGER,
  })
  venueId: number;

  @BelongsTo(() => Venue)
  venue: Venue;

  @ForeignKey(() => TicketStatus)
  @Column(DataType.INTEGER)
  ticketStatusId: number;


  @ForeignKey(() => CartStatus)
  @Column
  cartStatusId: number;

  @BelongsTo(() => CartStatus)
  cartStatus: CartStatus;

}
