import { Controller, Post, Get, Param, Body, Put, Delete } from '@nestjs/common';
import { SeatService } from './seat_service';
import { Seat } from './models/seat_model';
import { CreateSeatDto } from './dto/create_seat';
import { UpdateSeatDto } from './dto/update_seat';

@Controller('seats')
export class SeatController {
  constructor(private readonly seatService: SeatService) {}

  @Post()
  create(@Body() seatData: Partial<Seat>): Promise<Seat> {
    return this.seatService.create(seatData);
  }

  @Get()
  findAll(): Promise<Seat[]> {
    return this.seatService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: number): Promise<Seat> {
    return this.seatService.findOne(id);
  }

  @Put(':id')
  update(@Param('id') id: number, @Body() seatData: Partial<Seat>): Promise<[number, Seat[]]> {
    return this.seatService.update(id, seatData);
  }

  @Delete(':id')
  delete(@Param('id') id: number): Promise<void> {
    return this.seatService.delete(id);
  }
}
