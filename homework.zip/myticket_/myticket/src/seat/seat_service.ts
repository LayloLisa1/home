import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Seat } from './models/seat_model';

@Injectable()
export class SeatService {
  constructor(
    @InjectModel(Seat)
    private seatModel: typeof Seat,
  ) {}

  async create(seatData: Partial<Seat>): Promise<Seat> {
    return this.seatModel.create(seatData);
  }

  async findAll(): Promise<Seat[]> {
    return this.seatModel.findAll();
  }

  async findOne(id: number): Promise<Seat> {
    return this.seatModel.findByPk(id);
  }

  async update(id: number, seatData: Partial<Seat>): Promise<[number, Seat[]]> {
    return this.seatModel.update(seatData, {
      where: { id },
      returning: true,
    });
  }

  async delete(id: number): Promise<void> {
    const seat = await this.findOne(id);
    if (seat) {
      await seat.destroy();
    }
  }
}
