export class CreateCartStatusDto {
    name: string;
  }
  
  export class UpdateCartStatusDto {
    name?: string; 
  }
  