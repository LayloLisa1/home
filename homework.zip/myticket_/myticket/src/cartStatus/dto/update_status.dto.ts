import { IsOptional, IsString } from 'class-validator';

export class UpdateCartStatusDto {
  @IsOptional()
  @IsString()
  name?: string; 
}
