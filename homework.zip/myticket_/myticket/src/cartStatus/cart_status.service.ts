import { Injectable } from '@nestjs/common';
import { CartStatus } from './models/cart_status.model';

@Injectable()
export class CartStatusService {
  async create(createCartStatusDto: { name: string }) {
    return await CartStatus.create(createCartStatusDto);
  }

  async findAll() {
    return await CartStatus.findAll();
  }

  async findOne(id: number) {
    return await CartStatus.findByPk(id);
  }

  async update(id: number, updateCartStatusDto: { name: string }) {
    const cartStatus = await CartStatus.findByPk(id);
    if (cartStatus) {
      cartStatus.name = updateCartStatusDto.name;
      await cartStatus.save();
      return cartStatus;
    }
    return null;
  }

  async remove(id: number) {
    const cartStatus = await CartStatus.findByPk(id);
    if (cartStatus) {
      await cartStatus.destroy();
      return { deleted: true };
    }
    return { deleted: false };
  }
}
