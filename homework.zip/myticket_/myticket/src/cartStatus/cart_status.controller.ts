import { Body, Controller, Delete, Get, Param, Post, Put } from '@nestjs/common';
import { CartStatus } from './models/cart_status.model';
import { CartStatusService } from './cart_status.service';

@Controller('cart-status')
export class CartStatusController {
  constructor(private readonly cartStatusService: CartStatusService) {}

  @Post()
  async create(@Body() createCartStatusDto: { name: string }) {
    return this.cartStatusService.create(createCartStatusDto);
  }

  @Get()
  async findAll() {
    return this.cartStatusService.findAll();
  }

  @Get(':id')
  async findOne(@Param('id') id: number) {
    return this.cartStatusService.findOne(id);
  }

  @Put(':id')
  async update(@Param('id') id: number, @Body() updateCartStatusDto: { name: string }) {
    return this.cartStatusService.update(id, updateCartStatusDto);
  }

  @Delete(':id')
  async remove(@Param('id') id: number) {
    return this.cartStatusService.remove(id);
  }
}
