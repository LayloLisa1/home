import { Column, DataType, Model, Table, HasMany } from 'sequelize-typescript';
import { Seat } from 'src/seat/models/seat_model';
import { Venue } from 'src/venue/models/venue.model';

@Table
export class CartStatus extends Model<CartStatus> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  name: string;

  @HasMany(() => Seat)
  seats: Seat[];

  @HasMany(() => Venue)
  venues: Venue[];
}
