import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { SequelizeModule } from "@nestjs/sequelize";
import { HumanCategoryModule } from "./human_category/human_category.module";
import { HumanCategory } from "./human_category/models/human_category.mode"; // Fixed import path
import { SeatTypeModule } from "./seat_type/seat_type.module";
import { VenueTypeModule } from "./venue type/venue_type.module"; // Fixed import path
import { VenueModule } from "./venue/venue.module";
import { SeatType } from "./seat_type/models/seat_type.model";
import { VenueType } from "./venue type/models/venue_type.model"; // Fixed import path
import { Venue } from "./venue/models/venue.model";
import { VenuePhotoModule } from "./venue_photo/venue_photo.module";
import { VenuePhoto } from "./venue_photo/models/venue_photo.model";
import { Region } from "./region/models/region.models"; // Fixed import path
import { DistrictModule } from "./district/district.module";
import { SeatModule } from "./seat/seat_module"; // Fixed import path
import { TicketStatus } from "./TicketStatus/models/ticket_status_model"; // Fixed import path
import { CartStatus } from "./cartStatus/models/cart_status.model"; // Assuming you have a module for this
import { EventModule } from "./Event/event_module";
import { TicketStatusModule } from "./TicketStatus/ticket_status_module";
import { EventType } from "./EventType/models/event_type.model";

@Module({
  imports: [
    ConfigModule.forRoot({ envFilePath: ".env", isGlobal: true }),
    SequelizeModule.forRoot({
      dialect: "postgres",
      host: process.env.POSTGRES_HOST,
      port: +process.env.POSTGRES_PORT,
      username: process.env.POSTGRES_USER,
      password: process.env.POSTGRES_PASSWORD,
      database: process.env.POSTGRES_DB,
      models: [
        HumanCategory,
        SeatType,
        VenueType,
        Venue,
        VenuePhoto,
        Region,
        TicketStatus,
        
      ],
      autoLoadModels: true,
      sync: { alter: true },
      logging: true,
    }),
    HumanCategoryModule,
    SeatTypeModule,
    VenueTypeModule,
    VenueModule,
    VenuePhotoModule,
    DistrictModule,
    SeatModule,
    CartStatus,
    EventModule,
    TicketStatusModule,
    EventType,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
