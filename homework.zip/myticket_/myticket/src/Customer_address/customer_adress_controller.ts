import { Controller, Post, Get, Param, Patch, Delete, Body } from '@nestjs/common';
import { CustomerAddressService } from 'src/Customer_address/customer_adress_service';
import { CreateCustomerAddressDto } from './dto/create_customer_adress';
import { UpdateCustomerAddressDto} from './dto/update_customer_adress';

@Controller('customer-addresses')
export class CustomerAddressController {
  constructor(private readonly customerAddressService: CustomerAddressService) {}

  @Post()
  create(@Body() createCustomerAddressDto: CreateCustomerAddressDto) {
    return this.customerAddressService.create(createCustomerAddressDto);
  }

  @Get()
  findAll() {
    return this.customerAddressService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.customerAddressService.findOne(id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateCustomerAddressDto: UpdateCustomerAddressDto) {
    return this.customerAddressService.update(id, updateCustomerAddressDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.customerAddressService.remove(id);
  }
}
