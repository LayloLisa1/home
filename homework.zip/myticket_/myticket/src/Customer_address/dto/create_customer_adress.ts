import { IsNotEmpty, IsString } from 'class-validator';

export class CreateCustomerAddressDto {
  @IsNotEmpty()
  @IsString()
  addressLine: string;

  @IsNotEmpty()
  @IsString()
  city: string;

  @IsNotEmpty()
  @IsString()
  postalCode: string;

  @IsNotEmpty()
  @IsString()
  customerId: string; 
}
