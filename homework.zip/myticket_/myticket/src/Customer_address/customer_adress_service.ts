import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { CustomerAddress } from 'src/Customer_address/modules/customer_adress_model';
import { CreateCustomerAddressDto } from './dto/create_customer_adress';
import { UpdateCustomerAddressDto} from './dto/update_customer_adress'; 
@Injectable()
export class CustomerAddressService {
  constructor(@InjectModel(CustomerAddress) private customerAddressModel: typeof CustomerAddress) {}

  create(createCustomerAddressDto: CreateCustomerAddressDto) {
    return this.customerAddressModel.create(createCustomerAddressDto);
  }

  findAll() {
    return this.customerAddressModel.findAll();
  }

  findOne(id: string) {
    return this.customerAddressModel.findByPk(id);
  }

  update(id: string, updateCustomerAddressDto: UpdateCustomerAddressDto) {
    return this.customerAddressModel.update(updateCustomerAddressDto, { where: { id } });
  }

  remove(id: string) {
    return this.customerAddressModel.destroy({ where: { id } });
  }
}
