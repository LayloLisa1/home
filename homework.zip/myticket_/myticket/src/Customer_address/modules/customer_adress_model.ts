import { Column, Model, Table, DataType, ForeignKey } from 'sequelize-typescript';
import { Customer } from 'src/Customer/models/customer_model';

@Table
export class CustomerAddress extends Model<CustomerAddress> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  addressLine: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  city: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  postalCode: string;

  @ForeignKey(() => Customer)
  @Column({
    type: DataType.UUID,
    allowNull: false,
  })
  customerId: string; 
}



