import { Controller, Post, Get, Param, Patch, Delete, Body } from '@nestjs/common';
import { EventTypeService } from 'src/EventType/event-type.service';
import { CreateEventTypeDto } from 'src/EventType/dto/create-event_type'; 
import { UpdateEventTypeDto } from 'src/EventType/dto/update-event_type'; 

@Controller('event-type')
export class EventTypeController {
  constructor(private readonly eventTypeService: EventTypeService) {}

  @Post()
  create(@Body() createEventTypeDto: CreateEventTypeDto) {
    return this.eventTypeService.create(createEventTypeDto);
  }

  @Get()
  findAll() {
    return this.eventTypeService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) { 
    return this.eventTypeService.findOne(+id); 
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateEventTypeDto: UpdateEventTypeDto) {
    return this.eventTypeService.update(+id, updateEventTypeDto); 
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.eventTypeService.remove(+id); 
  }
}
