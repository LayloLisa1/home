import { Column, DataType, ForeignKey, Model, Table } from 'sequelize-typescript';
import { EventType } from 'src/EventType/models/event_type.model';
@Table({ tableName: 'event' })
export class Event extends Model<Event> {
  @Column({
    type: DataType.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  })
  id: number;

  @Column({ type: DataType.STRING, allowNull: false })
  name: string;

  @Column({ type: DataType.STRING })
  photo: string;

  @Column({ type: DataType.DATE })
  start_date: Date;

  @Column({ type: DataType.TIME })
  start_time: string;

  @Column({ type: DataType.DATE })
  finish_date: Date;

  @Column({ type: DataType.TEXT })
  info: string;

  @ForeignKey(() => EventType)
  @Column({ type: DataType.SMALLINT })
  event_type_id: number;

  @Column({ type: DataType.BIGINT })
  human_category_id: number;

  @Column({ type: DataType.BIGINT })
  venue_id: number;

  @Column({ type: DataType.SMALLINT })
  lang_id: number;

  @Column({ type: DataType.DATE })
  release_date: Date;
}
/**
- `POST /event-type`, `GET /event-type`, `PATCH /event-type/:id`, `DELETE /event-type/:id`
- `POST /events`, `GET /events`, `PATCH /events/:id`, `DELETE /events/:id`
- `GET /events/:id/sold-seats` — bu yerda "Sotilgan" statusdagi seatlar chiqariladi
- `POST /tickets`, `GET /tickets`, `PATCH /tickets/:id`, `DELETE /tickets/:id`

 */