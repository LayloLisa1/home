import { Module } from '@nestjs/common';
import { SequelizeModule } from '@nestjs/sequelize';
import { EventType } from 'src/EventType/models/event_type.model';
import { Event } from './models/event_model';
import { Ticket } from 'src/Ticket/models/ticket.model';
import { EventTypeController } from 'src/EventType/event-type.controller';
import { EventController } from 'src/Event/event-controller'; 
import { TicketController } from 'src/Ticket/ticket.controller';
import { EventTypeService } from 'src/EventType/event-type.service';
import { EventService } from 'src/Event/event_service'; 
import { TicketService } from 'src/Ticket/ticket.service';

@Module({
  imports: [SequelizeModule.forFeature([EventType, Event, Ticket])],
  controllers: [EventTypeController, EventController, TicketController],
  providers: [EventTypeService, EventService, TicketService],
})
export class EventModule {}
