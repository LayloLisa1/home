import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Event } from '../Event/models/event_model'; 
import { Ticket } from '../Ticket/models/ticket.model'
;import { CreateEventDto } from '../Event/dto/create_event.dto'; 
import { UpdateEventDto } from '../Event/dto/update_event.dto'; 

@Injectable()
export class EventService {
  constructor(
    @InjectModel(Event) private eventModel: typeof Event,
    @InjectModel(Ticket) private ticketModel: typeof Ticket
  ) {}
  create(createEventDto: CreateEventDto) {
    return this.eventModel.create(createEventDto);
  }
  findAll() {
    return this.eventModel.findAll();
  }
  findOne(id: number) {
    return this.eventModel.findByPk(id);
  }
  async findEventWithSoldSeats(eventId: number) {
    const event = await this.eventModel.findByPk(eventId, {
      include: [{
        model: this.ticketModel,
        where: { status_id: 2 }, 
        attributes: ['seat_id']
      }]
    });

    if (!event) {
      throw new NotFoundException(`Event with ID ${eventId} not found`);
    }

    return event;
  }
  update(id: number, updateEventDto: UpdateEventDto) {
    const updatedEvent = this.eventModel.update(updateEventDto, { where: { id } });

    if (!updatedEvent) {
      throw new NotFoundException(`Event with ID ${id} not found`);
    }

    return updatedEvent;
  }
  remove(id: number) {
    const deletedEvent = this.eventModel.destroy({ where: { id } });

    if (!deletedEvent) {
      throw new NotFoundException(`Event with ID ${id} not found`);
    }

    return deletedEvent;
  }
}
