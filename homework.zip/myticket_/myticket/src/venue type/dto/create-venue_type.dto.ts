export class CreateVenueTypeDto {
  name: string;
}
