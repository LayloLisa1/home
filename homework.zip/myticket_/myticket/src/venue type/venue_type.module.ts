import { Module } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import { VenueType } from "./models/venue_type.model";
import { VenueTypeController } from "./venue_type.controller";
import { VenueTypeService } from "./venue_type.service";

@Module({
  imports: [SequelizeModule.forFeature([VenueType])],
  controllers: [VenueTypeController],
  providers: [VenueTypeService],
})
export class VenueTypeModule {}
