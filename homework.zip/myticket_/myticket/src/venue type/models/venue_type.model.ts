import { Column, DataType, Model, Table } from "sequelize-typescript";

interface VenueTypeAttr {
  name: string;
}

@Table({ tableName: "venue_type" })
export class VenueType extends Model<VenueType, VenueTypeAttr> {
  @Column({
    type: DataType.STRING(),
    allowNull: false,
    unique: true,
  })
  name: string;
}
