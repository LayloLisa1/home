import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/sequelize";
import { CreateVenueTypeDto } from "./dto/create-venue_type.dto";
import { VenueType } from "./models/venue_type.model";
import { UpdateVenueTypeDto } from "./dto/update-venue_type.dto";

@Injectable()
export class VenueTypeService {
  constructor(
    @InjectModel(VenueType) private venueTypeModel: typeof VenueType
  ) {}
  async createVenueType(
    createVenueTypeDto: CreateVenueTypeDto
  ): Promise<VenueType> {
    const venue_type = await this.venueTypeModel.create(createVenueTypeDto);
    return venue_type;
  }
  async getAllVenueTypes(): Promise<VenueType[]> {
    return this.venueTypeModel.findAll();
  }
  async getVenueTypeById(id: number): Promise<VenueType> {
    return this.venueTypeModel.findByPk(id);
  }
  async geVenueVenueTypeByName(name: string): Promise<VenueType> {
    return this.venueTypeModel.findOne({ where: { name } });
  }
  async deleteVenueType(id: number): Promise<number> {
    return this.venueTypeModel.destroy({ where: { id } });
  }
  async updateVenueType(
    id: number,
    updateVenueTypeDto: UpdateVenueTypeDto
  ): Promise<VenueType> {
    const Venue_type = await this.venueTypeModel.update(updateVenueTypeDto, {
      where: { id },
      returning: true,
    });
    console.log(Venue_type);
    return Venue_type[1][0];
  }
}
